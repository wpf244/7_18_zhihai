<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:88:"D:\phpstudy\PHPTutorial\WWW\7_18_zhihai\public/../application/admin\view\dancer\add.html";i:1563439043;s:81:"D:\phpstudy\PHPTutorial\WWW\7_18_zhihai\application\admin\view\public\header.html";i:1558689191;s:78:"D:\phpstudy\PHPTutorial\WWW\7_18_zhihai\application\admin\view\public\nav.html";i:1545995382;s:79:"D:\phpstudy\PHPTutorial\WWW\7_18_zhihai\application\admin\view\public\left.html";i:1561512727;s:78:"D:\phpstudy\PHPTutorial\WWW\7_18_zhihai\application\admin\view\public\set.html";i:1545995382;s:81:"D:\phpstudy\PHPTutorial\WWW\7_18_zhihai\application\admin\view\public\footer.html";i:1561512958;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta charset="utf-8" />
<title><?php echo $sys['name']; ?></title>

<meta name="description" content="overview &amp; stats" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<!-- <link rel="shortcut icon" href="public/favico.ico"> -->

<!-- bootstrap & fontawesome -->
<link rel="stylesheet" href="/static/admin/assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="/static/admin/assets/font-awesome/4.7.0/css/font-awesome.min.css" />

<!-- page specific plugin styles -->
<link rel="stylesheet" href="/static/admin/assets/css/jquery-ui.custom.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/jquery.gritter.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/bootstrap-datepicker3.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/bootstrap-timepicker.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/daterangepicker.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/colorbox.min.css" />

<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/assets/css/fonts.googleapis.com.css" />

<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

<!--[if lte IE 9]>
<link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
<![endif]-->
<link rel="stylesheet" href="/static/admin/assets/css/ace-skins.min.css" />
<link rel="stylesheet" href="/static/admin/assets/css/ace-rtl.min.css" />

<!--[if lte IE 9]>
<link rel="stylesheet" href="assets/css/ace-ie.min.css" />
<![endif]-->
<link rel="stylesheet" href="/static/admin/css/style.min.css">
<link rel="stylesheet" href="/static/admin/css/input.css">

<!-- inline styles related to this page -->
 <!-- <link rel="stylesheet" href="/static/admin/layui/css/layui.css"  media="all"> -->
<!-- ace settings handler -->
<script src="/static/admin/assets/js/ace-extra.min.js"></script>

<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

<!--[if lte IE 8]>
<script src="assets/js/html5shiv.min.js"></script>
<script src="assets/js/respond.min.js"></script>
<![endif]-->
<!-- basic scripts -->

<!--[if !IE]> -->
<script src="/static/admin/assets/js/jquery-2.1.4.min.js"></script>
<script src="/static/admin/js/input.js"></script>
<script src="/static/admin/js/zh.js"></script>

<!-- <![endif]-->

<!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
<script type="text/javascript">
  if('ontouchstart' in document.documentElement) document.write("<script src='/static/admin/assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="/static/admin/assets/js/bootstrap.min.js"></script>

<!-- page specific plugin scripts -->

<!--[if lte IE 8]>
<script src="assets/js/excanvas.min.js"></script>
<![endif]-->
<script src="/static/admin/assets/js/jquery-ui.custom.min.js"></script>
<script src="/static/admin/assets/js/jquery.ui.touch-punch.min.js"></script>
<script src="/static/admin/assets/js/bootbox.js"></script>
<script src="/static/admin/assets/js/jquery.easypiechart.min.js"></script>
<script src="/static/admin/assets/js/jquery.gritter.min.js"></script>
<script src="/static/admin/assets/js/jquery.sparkline.index.min.js"></script>
<script src="/static/admin/assets/js/jquery.inputlimiter.min.js"></script>
<script src="/static/admin/assets/js/jquery.colorbox.min.js"></script>
<!--日期选择-->
<script src="/static/admin/assets/js/bootstrap-datepicker.js"></script>
<script src="/static/admin/assets/js/locales/bootstrap-datepicker.zh-CN.js"></script>
<script src="/static/admin/assets/js/bootstrap-timepicker.min.js"></script>
<script src="/static/admin/assets/js/moment.min.js"></script>
<script src="/static/admin/assets/js/daterangepicker.min.js"></script>
<script src="/static/admin/assets/js/bootstrap-datetimepicker.min.js"></script>

<!--表单验证-->
<script src="/static/admin/assets/js/wizard.min.js"></script>
<script src="/static/admin/assets/js/jquery.validate.min.js"></script>
<!--<script src="assets/js/jquery.flot.min.js"></script>-->
<!--<script src="assets/js/jquery.flot.pie.min.js"></script>-->
<!--<script src="assets/js/jquery.flot.resize.min.js"></script>-->
<!--增加-->
<script src="/static/admin/assets/layer/layer.js"></script>
<script src="/static/admin/assets/js/jquery.form.js"></script>
<!-- ace scripts -->
<script src="/static/admin/assets/js/ace-elements.min.js"></script>
<script src="/static/admin/assets/js/ace.min.js"></script>
<script src="/static/admin/js/main.js"></script>
<!--表单验证-->
<script src="/static/admin/js/Validform_v5.3.2_min.js"></script>
<script src="/static/admin/assets/js/jquery.form.js"></script>
  <script src="/static/admin/assets/js/jquery.maskedinput.min.js"></script>
  <script src="/static/admin/assets/js/jquery-typeahead.js"></script>
  <script src="/static/admin/laydate/laydate/laydate.js"></script>

<style>
    /*==========以下部分是Validform必须的===========*/
    .Validform_checktip{
      margin-left:8px;
      line-height:20px;
      height:20px;
      overflow:hidden;
      color:#999;
      font-size:12px;
    }
    .Validform_right{
      color:#71b83d;
      padding-left:20px;
      background:url(/static/admin/img/right.png) no-repeat left center;
    }
    .Validform_wrong{
      color:red;
      padding-left:20px;
      white-space:nowrap;
      background:url(/static/admin/img/error.png) no-repeat left center;
    }
    .Validform_loading{
      padding-left:20px;
      background:url(/static/admin/img/onLoad.gif) no-repeat left center;
    }
    .Validform_error{
      background-color:#ffe7e7;
    }
    #Validform_msg{color:#7d8289; font: 12px/1.5 tahoma, arial, \5b8b\4f53, sans-serif; width:280px; -webkit-box-shadow:2px 2px 3px #aaa; -moz-box-shadow:2px 2px 3px #aaa; background:#fff; position:absolute; top:0px; right:50px; z-index:99999; display:none;filter: progid:DXImageTransform.Microsoft.Shadow(Strength=3, Direction=135, Color='#999999');}
    #Validform_msg .iframe{position:absolute; left:0px; top:-1px; z-index:-1;}
    #Validform_msg .Validform_title{line-height:25px; height:25px; text-align:left; font-weight:bold; padding:0 8px; color:#fff; position:relative; background-color:#000;}
    #Validform_msg a.Validform_close:link,#Validform_msg a.Validform_close:visited{line-height:22px; position:absolute; right:8px; top:0px; color:#fff; text-decoration:none;}
    #Validform_msg a.Validform_close:hover{color:#cc0;}
    #Validform_msg .Validform_info{padding:8px;border:1px solid #000; border-top:none; text-align:left;}
  </style>
</head>

<body class="no-skin">
<!--头部-->
<div id="navbar" class="navbar navbar-default          ace-save-state">
  <div class="navbar-container ace-save-state" id="navbar-container">
    <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
      <span class="sr-only">Toggle sidebar</span>

      <span class="icon-bar"></span>

      <span class="icon-bar"></span>

      <span class="icon-bar"></span>
    </button>

    <div class="navbar-header pull-left">
      <a href="<?php echo url('Index/index'); ?>" class="navbar-brand">
        <small>
          <i class="fa fa-leaf"></i>
          <?php echo $sys['name']; ?>CMS
        </small>
      </a>
    </div>

    <div class="navbar-buttons navbar-header pull-right" role="navigation">
      <ul class="nav ace-nav">
        
        <li class="light-blue dropdown-modal">
          <a data-toggle="dropdown" href="#" class="dropdown-toggle">
            <img class="nav-user-photo" src="/static/admin/assets/images/avatars/user.png" alt="Jason's Photo" />
            <span class="user-info">
									<small>欢迎登录</small>
									<?php echo $admin['username']; ?>
								</span>

            <i class="ace-icon fa fa-caret-down"></i>
          </a>

          <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
            <li>
						<a href="<?php echo url('Index/modify'); ?>">
							<i class="ace-icon fa fa-user"></i> 修改密码
						</a>
					</li>
            <li>
              <a id="power-off" href="javascript:;">
                <i class="ace-icon fa fa-power-off"></i>
                退出
              </a>
            </li>
          <script> 
             //退出系统
  $("#power-off").on(ace.click_event,function(){
    layer.confirm('是否退出系统?',{icon: 3},function (index) {
      location.href = "<?php echo url('Login/logout'); ?>";
      layer.close(index);
    });
  })
  </script>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</div>

<div class="main-container ace-save-state" id="main-container">
  <!--菜单-->
  <script type="text/javascript">
  try{ace.settings.loadState('main-container')}catch(e){}
</script>

<div id="sidebar" class="sidebar                  responsive                    ace-save-state">
  <script type="text/javascript">
    try{ace.settings.loadState('sidebar')}catch(e){}
  </script>

  <div class="sidebar-shortcuts" id="sidebar-shortcuts">
    <div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
      <a  class="btn btn-success" href="<?php echo url('Index/index/index'); ?>" target="_blank" title="前台首页">
        <i class="ace-icon fa fa-globe"></i>
      </a>

      <a class="btn btn-info" href="javascript:;" data-rel="tooltip" data-placement="bottom" title="添加文章">
        <i class="ace-icon fa fa-pencil"></i>
      </a>

      <a class="btn btn-warning" href="<?php echo url('Sys/seo'); ?>" data-rel="tooltip" data-placement="bottom" title="网站优化">
        <i class="ace-icon fa fa-wrench"></i>
      </a>

      <button class="btn btn-danger tooltip-error" id="cache" data-rel="tooltip" data-placement="bottom" title="清除缓存">
        <i class="ace-icon fa fa-refresh"></i>
      </button>
    </div>
<script>
$(function(){
	$("#cache").on(ace.click_event,function(){
	    layer.confirm('确认要清除缓存?',{icon: 3},function (index) {
	    	$.post("<?php echo url('Index/clearruntime'); ?>",{user:1},function(data){
	    		layer.alert("缓存清理成功");
	    		});
	      layer.close(index);
	    });
	  })
	
	});
</script>
    <div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
      <span class="btn btn-success"></span>

      <span class="btn btn-info"></span>

      <span class="btn btn-warning"></span>

      <span class="btn btn-danger"></span>
    </div>
  </div><!-- /.sidebar-shortcuts -->

  <ul class="nav nav-list">
    <?php if(CONTROLLER_NAME == 'Index'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
      <a href="<?php echo url('Index/index'); ?>">
        <i class="menu-icon fa fa-tachometer"></i>
        <span class="menu-text"> 控制台 </span>
      </a>

      <b class="arrow"></b>
    </li>
 <?php if(is_array($controls) || $controls instanceof \think\Collection || $controls instanceof \think\Paginator): $i = 0; $__LIST__ = $controls;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$c): $mod = ($i % 2 );++$i;if(CONTROLLER_NAME == $c['c_modul']): ?><li class="open"><?php else: ?><li class=""><?php endif; ?>
      <a href="#" class="dropdown-toggle">
        <i class="menu-icon fa <?php echo $c['c_icon']; ?>"></i>
        <span class="menu-text"> <?php echo $c['c_name']; ?> </span>
        
        <b class="arrow fa fa-angle-down"></b>
      </a>

      <b class="arrow"></b>
      <ul class="submenu">
       <?php if(is_array($c['ways']) || $c['ways'] instanceof \think\Collection || $c['ways'] instanceof \think\Paginator): $i = 0; $__LIST__ = $c['ways'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$w): $mod = ($i % 2 );++$i;if(ACTION_NAME == $w['c_modul']): ?><li class="active"><?php else: ?><li class=""><?php endif;  $url = $c['c_modul'].'/'.$w['c_modul']; ?>
          <a href="<?php echo url($url); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            <?php echo $w['c_name']; ?>  
          </a>
          
          <b class="arrow"></b>
        </li>
      <?php endforeach; endif; else: echo "" ;endif; ?>
       
      </ul>
    </li>
<?php endforeach; endif; else: echo "" ;endif; ?>
    <!-- <?php if(CONTROLLER_NAME == 'Lb'): ?><li class="open"><?php else: ?><li class=""><?php endif; ?>
      <a href="#" class="dropdown-toggle">
        <i class="menu-icon fa fa-picture-o"></i>
        <span class="menu-text"> 广告图管理 </span>
        <b class="arrow fa fa-angle-down"></b>
      </a>

      <b class="arrow"></b>
      <ul class="submenu">
       <?php if(ACTION_NAME == 'lister'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Lb/lister'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            图片列表
          </a>

          <b class="arrow"></b>
        </li>

        <?php if(ACTION_NAME == 'place'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Lb/place'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            广告位
          </a>

          <b class="arrow"></b>
        </li>
      </ul>
    </li>
    
    <?php if(CONTROLLER_NAME == 'Shops'): ?><li class="open"><?php else: ?><li class=""><?php endif; ?>
      <a href="#" class="dropdown-toggle">
        <i class="menu-icon fa fa-balance-scale"></i>
        <span class="menu-text"> 店铺管理 </span>
        <b class="arrow fa fa-angle-down"></b>
      </a>

      <b class="arrow"></b>
      <ul class="submenu">
       <?php if(ACTION_NAME == 'lister'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Shops/lister'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            店铺列表
          </a>

          <b class="arrow"></b>
        </li>
        
         <?php if(ACTION_NAME == 'add'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Shops/add'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            添加店铺
          </a>

          <b class="arrow"></b>
        </li>

      </ul>
    </li>

       <?php if(CONTROLLER_NAME == 'Goods'): ?><li class="open"><?php else: ?><li class=""><?php endif; ?>
      <a href="#" class="dropdown-toggle">
        <i class="menu-icon fa fa-paper-plane"></i>
        <span class="menu-text"> 商品管理 </span>

        <b class="arrow fa fa-angle-down"></b>
      </a>

      <b class="arrow"></b>

      <ul class="submenu">
        <?php if(ACTION_NAME == 'lister'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Goods/lister'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            商品列表
          </a>

          <b class="arrow"></b>
        </li>
     <?php if(ACTION_NAME == 'type'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Goods/goods_type'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            商品分类
          </a>

          <b class="arrow"></b>
        </li>
     
      </ul>

    </li>

    <?php if(CONTROLLER_NAME == 'Carte'): ?><li class="open"><?php else: ?><li class=""><?php endif; ?>
      <a href="#" class="dropdown-toggle">
        <i class="menu-icon fa fa-reorder"></i>
        <span class="menu-text"> 菜单管理 </span>

        <b class="arrow fa fa-angle-down"></b>
      </a>

      <b class="arrow"></b>

      <ul class="submenu">
        <?php if(ACTION_NAME == 'lister'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
          <a href="<?php echo url('Carte/lister'); ?>">
            <i class="menu-icon fa fa-caret-right"></i>
            后台模块
          </a>

          <b class="arrow"></b>
        </li>
    
     
      </ul>

    </li>
    
    <?php if(CONTROLLER_NAME == 'User'): ?><li class="open"><?php else: ?><li class=""><?php endif; ?>
        <a href="#" class="dropdown-toggle">
          <i class="menu-icon fa fa-reorder"></i>
          <span class="menu-text"> 管理员管理 </span>
  
          <b class="arrow fa fa-angle-down"></b>
        </a>
  
        <b class="arrow"></b>
  
        <ul class="submenu">
          <?php if(ACTION_NAME == 'lister'): ?><li class="active"><?php else: ?><li class=""><?php endif; ?>
            <a href="<?php echo url('User/lister'); ?>">
              <i class="menu-icon fa fa-caret-right"></i>
              管理员列表
            </a>
  
            <b class="arrow"></b>
          </li>
      
       
        </ul>
  
      </li> -->
  
  

  
    
  </ul><!-- /.nav-list -->

  <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
    <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
  </div>
</div>

  <div class="main-content">
    <div class="main-content-inner">
      <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
          <li>
            <i class="ace-icon fa fa-home home-icon"></i>
            <a href="<?php echo url('Index/index'); ?>">首页</a>
          </li>
          <li class="active">添加舞者</li>
        </ul><!-- /.breadcrumb -->

      </div>

      <div class="page-content">

         <div class="ace-settings-container" id="ace-settings-container">
  <div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
    <i class="ace-icon fa fa-cog bigger-130"></i>
  </div>

  <div class="ace-settings-box clearfix" id="ace-settings-box">
    <div class="pull-left width-50">
      <div class="ace-settings-item">
        <div class="pull-left">
          <select id="skin-colorpicker" class="hide">
            <option data-skin="no-skin" value="#438EB9">#438EB9</option>
            <option data-skin="skin-1" value="#222A2D">#222A2D</option>
            <option data-skin="skin-2" value="#C6487E">#C6487E</option>
            <option data-skin="skin-3" value="#D0D0D0">#D0D0D0</option>
          </select>
        </div>
        <span>&nbsp; 换肤</span>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-navbar" autocomplete="off" />
        <label class="lbl" for="ace-settings-navbar"> 固定导航条</label>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-sidebar" autocomplete="on" />
        <label class="lbl" for="ace-settings-sidebar"> 固定侧边栏</label>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-breadcrumbs" autocomplete="off" />
        <label class="lbl" for="ace-settings-breadcrumbs"> 固定面包屑导航</label>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-rtl" autocomplete="off" />
        <label class="lbl" for="ace-settings-rtl"> 侧边栏从左到右 (rtl)</label>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-add-container" autocomplete="off" />
        <label class="lbl" for="ace-settings-add-container">
          内部
          <b>居中</b>
        </label>
      </div>
    </div><!-- /.pull-left -->

    <div class="pull-left width-50">
      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-hover" autocomplete="off" />
        <label class="lbl" for="ace-settings-hover"> 鼠标经过展开子菜单</label>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-compact" autocomplete="off" />
        <label class="lbl" for="ace-settings-compact"> 紧凑型侧边栏</label>
      </div>

      <div class="ace-settings-item">
        <input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-highlight" autocomplete="off" />
        <label class="lbl" for="ace-settings-highlight"> Alt. Active Item</label>
      </div>
    </div><!-- /.pull-left -->
  </div><!-- /.ace-settings-box -->
</div><!-- /.ace-settings-container -->


        <div class="row">
          <div class="col-xs-12">
            <div class="col-sm-10 col-sm-offset-1">
              <form id="logoForm" class="form-horizontal" action="<?php echo url('Dancer/saves'); ?>" method="post" enctype="multipart/form-data">
                <div class="row">
                  <div class="col-sm-7">
                    <div class="widget-box transparent">
                      <div class="widget-header widget-header-flat">
                        <h4 class="widget-title"><i class="ace-icon fa fa-leaf green"></i>舞者信息</h4>
                      </div>
                      <div class="widget-body">
                        <div class="widget-main">

                            <div class="form-group">
                                <label class="col-sm-2 control-label no-padding-right" for="">专业</label>
                                    <div class="col-sm-10">
                                      <select class="form-control" name="major"   required>
                                        
                                        <?php if(is_array($major) || $major instanceof \think\Collection || $major instanceof \think\Paginator): $i = 0; $__LIST__ = $major;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                        <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                                       <?php endforeach; endif; else: echo "" ;endif; ?>
                                      </select>
                                    </div> 
        
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="">学历</label>
                                        <div class="col-sm-10">
                                          <select class="form-control" name="edu"  >
                                              <?php if(is_array($edu) || $edu instanceof \think\Collection || $edu instanceof \think\Paginator): $i = 0; $__LIST__ = $edu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ve): $mod = ($i % 2 );++$i;?>
                                              <option value="<?php echo $ve['id']; ?>"><?php echo $ve['name']; ?></option>
                                             <?php endforeach; endif; else: echo "" ;endif; ?>
                                            
                                          </select>
                                        </div> 
            
                                    </div>
                    
                          <div class="form-group">
                            <label class="col-sm-2 control-label no-padding-right" for="">姓名</label>
                            <div class="col-sm-10">
                              <input class="form-control" type="text" name="username" required placeholder="请输入姓名" >
                            </div>
                            
                          </div>

                          <div class="form-group">
                            <label class="col-sm-2 control-label no-padding-right" for="">性别</label>
                            <div class="col-sm-10">
                              <input class="form-control" type="text" name="sex" required placeholder="请输入性别" >
                            </div>
                            
                          </div>
                                                                           
                          <div class="form-group">
                            <label class="col-sm-2 control-label no-padding-right" for="">出生年月</label>
                            <div class="col-sm-10">
                              <input class="form-control" type="text"  name="birth" placeholder="请输入出生年月">
                            </div>
                          </div>
                         
                       


                          <div class="form-group">
                              <label class="col-sm-2 control-label no-padding-right" for="">地址</label>
                              <div class="col-sm-10">
                                <input class="form-control" type="text" name="addr"  placeholder="请输入地址" >
                              </div>
                              
                            </div>


                            <div class="form-group">
                              <label class="col-sm-2 control-label no-padding-right" for="">手机号码</label>
                              <div class="col-sm-10">
                                <input class="form-control" type="text" name="phone" placeholder="请输入手机号码" >
                              </div>
                              
                            </div>

                          
                          

                          <div class="form-group">
                              <label class="col-sm-2 control-label no-padding-right" for="">职业标签</label>
                              <div class="col-sm-10">
                               <?php if(is_array($tag) || $tag instanceof \think\Collection || $tag instanceof \think\Paginator): $i = 0; $__LIST__ = $tag;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vs): $mod = ($i % 2 );++$i;?>
                               <div  class="col-sm-3">
                               <div class="checkbox">
                                  <label>
                                    <input  class="ace ace-checkbox-2" type="checkbox" name="tag[]" value="<?php echo $vs['id']; ?>">
                                    <span class="lbl"> <?php echo $vs['name']; ?></span>
                                  </label>
                                </div>
                              </div>
                               
                             <?php endforeach; endif; else: echo "" ;endif; ?>
                              </div>
                            
                            </div>

                      
                     
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div class="col-sm-5">
                    <div class="widget-box transparent">
                      <div class="widget-header widget-header-flat">
                        <h4 class="widget-title"><i class="ace-icon fa fa-leaf green"></i>图片</h4>
                      </div>
                      <div class="widget-body">
                        <div class="widget-main">
                          <div class="form-group">
                            <div class="col-xs-12">
                              <input multiple="" type="file" id="thumb" name="image" required />
                            </div>
                          </div>

                   
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  
                  
                </div>
                
       
               
                <div class="row">
                
                  <div class="col-sm-6">
                      <div class="widget-header widget-header-flat">
                          <h4 class="widget-title"><i class="ace-icon fa fa-leaf green"></i>个人介绍</h4>
                        </div>  
                
                    <textarea name="marray" style="width:100%; height: 200px;" ></textarea>
                    
                  </div>

                  <div class="col-sm-6">
                      <div class="widget-header widget-header-flat">
                          <h4 class="widget-title"><i class="ace-icon fa fa-leaf green"></i>工作经历</h4>
                        </div>  
                
                    <textarea name="work" style="width:100%; height: 200px;" ></textarea>
                    
                  </div>

                </div>

                <div class="row">
                
                    <div class="col-sm-6">
                        <div class="widget-header widget-header-flat">
                            <h4 class="widget-title"><i class="ace-icon fa fa-leaf green"></i>教育经历</h4>
                          </div>  
                  
                      <textarea name="edu_history" style="width:100%; height: 200px;" ></textarea>
                      
                    </div>
  
                    <div class="col-sm-6">
                        <div class="widget-header widget-header-flat">
                            <h4 class="widget-title"><i class="ace-icon fa fa-leaf green"></i>培训经历</h4>
                          </div>  
                  
                      <textarea name="train" style="width:100%; height: 200px;" ></textarea>
                      
                    </div>
  
                  </div>

                <div class="clearfix form-actions">
                  <div class="col-md-offset-3 col-md-9">
                   
                    <button class="btn btn-info" type="submit">
                      <i class="ace-icon fa fa-floppy-o bigger-110"></i>
                      保存
                    </button>
                    <button class="btn" type="reset">
                      <i class="ace-icon fa fa-undo bigger-110"></i>
                      重置
                    </button>
                  </div>
                </div>
              </form>
              <!-- PAGE CONTENT BEGINS -->
            </div>
            <!-- PAGE CONTENT ENDS -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.page-content -->
    </div>
  </div><!-- /.main-content -->

  <div class="footer">
  <div class="footer-inner">
    <div class="footer-content">
						<span class="bigger-110">
							<span class="blue bolder">Ace</span>
							<?php echo $sys['name']; ?> &copy; 2018-2020
						</span>
						<span class="bigger-110">
							<span class="blue bolder">技术支持:</span>
							<a href="http://www.dd371.com" target="_blank">朵朵科技</a>
						</span>
      &nbsp; &nbsp;
     
      <!--<span class="action-buttons">-->
							<!--<a href="#">-->
								<!--<i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i>-->
							<!--</a>-->

							<!--<a href="#">-->
								<!--<i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>-->
							<!--</a>-->

							<!--<a href="#">-->
								<!--<i class="ace-icon fa fa-rss-square orange bigger-150"></i>-->
							<!--</a>-->
						<!--</span>-->
    </div>
  </div>
</div>

<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
  <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>
</div><!-- /.main-container -->


<script>
  jQuery(function($) {
    $('[data-rel=tooltip]').tooltip();

    $( "#hide-option" ).tooltip({
      hide: {
        effect: "explode",
        delay: 250
      }
    });

  })

  $("#sid").change(function(){
   var sid = $("#sid").val();
 
   
    $.ajax({
       type:"post",
       url:"<?php echo url('Shop/getnexts'); ?>",
       data:{sid:sid},
       datatype:"text",
       success:function(re)
       {
        if(re != 0){
            var data = JSON.parse(re);
            $('#cid').html('<option value="0">请选择分类</option>');
            for(var j=0;j<data.length;j++){
             
              $('#cid').append('<option value="'+ data[j].id +'">'+data[j].name+'</option>');
            }
        }else{
          
          $('#cid').html('<option value="0">请选择分类</option>');
        } 
      
          
       }
    })

 })

 $("#addr").change(function(){
   var addr = $("#addr").val();
 
   
    $.ajax({
       type:"post",
       url:"<?php echo url('Shop/query_address'); ?>",
       data:{addr:addr},
       datatype:"text",
       success:function(re)
       {
         if(re == 0){
           layer.msg("自动定位失败请手动输入经纬度")
         }else{
            $("#longs").val(re.lng);
            $("#lats").val(re.lat);
         }
      
          
       }
    })

 })

</script>




  <script>
    $(function () {
      $('#thumb').ace_file_input({
        style: 'well',
        btn_choose: 'logo',
        btn_change: null,
        no_icon: 'ace-icon fa fa-picture-o',
        droppable: true,
        thumbnail: 'fit'//large | fit
        //,icon_remove:null//set null, to hide remove/reset button
        /**,before_change:function(files, dropped) {
						//Check an example below
						//or examples/file-upload.html
						return true;
					}*/
        /**,before_remove : function() {
						return true;
					}*/
        ,
        preview_error: function (filename, error_code) {
          //name of the file that failed
          //error_code values
          //1 = 'FILE_LOAD_FAILED',
          //2 = 'IMAGE_LOAD_FAILED',
          //3 = 'THUMBNAIL_FAILED'
          //alert(error_code);
        }

      }).on('change', function () {
        //console.log($(this).data('ace_input_files'));
        //console.log($(this).data('ace_input_method'));
      });
      
      $('#thumbs').ace_file_input({
          style: 'well',
          btn_choose: '微信二维码',
          btn_change: null,
          no_icon: 'ace-icon fa fa-picture-o',
          droppable: true,
          thumbnail: 'fit'//large | fit
          //,icon_remove:null//set null, to hide remove/reset button
          /**,before_change:function(files, dropped) {
  						//Check an example below
  						//or examples/file-upload.html
  						return true;
  					}*/
          /**,before_remove : function() {
  						return true;
  					}*/
          ,
          preview_error: function (filename, error_code) {
            //name of the file that failed
            //error_code values
            //1 = 'FILE_LOAD_FAILED',
            //2 = 'IMAGE_LOAD_FAILED',
            //3 = 'THUMBNAIL_FAILED'
            //alert(error_code);
          }

        }).on('change', function () {
          //console.log($(this).data('ace_input_files'));
          //console.log($(this).data('ace_input_method'));
        });
      
      $('#thumbj').ace_file_input({
          style: 'well',
          btn_choose: '节日专区图',
          btn_change: null,
          no_icon: 'ace-icon fa fa-picture-o',
          droppable: true,
          thumbnail: 'fit'//large | fit
          //,icon_remove:null//set null, to hide remove/reset button
          /**,before_change:function(files, dropped) {
  						//Check an example below
  						//or examples/file-upload.html
  						return true;
  					}*/
          /**,before_remove : function() {
  						return true;
  					}*/
          ,
          preview_error: function (filename, error_code) {
            //name of the file that failed
            //error_code values
            //1 = 'FILE_LOAD_FAILED',
            //2 = 'IMAGE_LOAD_FAILED',
            //3 = 'THUMBNAIL_FAILED'
            //alert(error_code);
          }

        }).on('change', function () {
          //console.log($(this).data('ace_input_files'));
          //console.log($(this).data('ace_input_method'));
        });
      
      $('#thumby').ace_file_input({
          style: 'well',
          btn_choose: '宴会专区图',
          btn_change: null,
          no_icon: 'ace-icon fa fa-picture-o',
          droppable: true,
          thumbnail: 'fit'//large | fit
          //,icon_remove:null//set null, to hide remove/reset button
          /**,before_change:function(files, dropped) {
  						//Check an example below
  						//or examples/file-upload.html
  						return true;
  					}*/
          /**,before_remove : function() {
  						return true;
  					}*/
          ,
          preview_error: function (filename, error_code) {
            //name of the file that failed
            //error_code values
            //1 = 'FILE_LOAD_FAILED',
            //2 = 'IMAGE_LOAD_FAILED',
            //3 = 'THUMBNAIL_FAILED'
            //alert(error_code);
          }

        }).on('change', function () {
          //console.log($(this).data('ace_input_files'));
          //console.log($(this).data('ace_input_method'));
        });

      $("#article").ajaxForm({
        // url: 'links.html',
        // type: 'post',
        // success: fun
      })
    });

    //响应请求回调
    function fun() {

    }

  </script>
  <script>
$(function(){
	$('#logoForm').ajaxForm({
		beforeSubmit: checkForm, // 此方法主要是提交前执行的方法，根据需要设置
		success: complete, // 这是提交后的方法
		dataType: 'json'
	});
	
	function checkForm(){
	  
		
    }

	function complete(data){
		if(data.status==1){
			layer.alert(data.msg, {icon: 5}, function(index){
 			layer.close(index);
 			window.location.href=data.url;
			});
			
		}else{
			layer.alert(data.msg, {icon: 6}, function(index){
 			layer.close(index);
 			window.location.href=data.url;
			});
			
		}
	}
 
});

</script>
</body>
</html>
