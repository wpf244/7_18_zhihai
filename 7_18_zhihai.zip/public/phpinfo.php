<?php
 phpinfo();
?><?php
 phpinfo();
?>