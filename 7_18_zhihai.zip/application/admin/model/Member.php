<?php
namespace app\admin\model;

use Think\Model;

class Member extends Model
{

}